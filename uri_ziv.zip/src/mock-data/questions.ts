export const questions = [
    {
        id: 1,
        question: "What is the capital of France?",
        options: ["Paris", "London", "Berlin", "Rome"],
        correctAnswer: "Paris"
    },
    {
        id: 2,
        question: "Where do Tigers live?",
        options: ["Africa", "The moon", "Petah-tikva", "New York"],
        correctAnswer: "Africa"
    },
    {
        id: 3,
        question: "a Turing machine, is named after : __",
        options: ["Alan Turing", "Cristiano Ronaldo", "Elon Turing", "The Turing brother"],
        correctAnswer: "Alan Turing"
    },
    {
        id: 4,
        question: "if two witches watch two watches, which witch watches which watch?",
        options: ["witch 1 watches watch 2", "witch 2 watches watch 1", "witch 1 watches watch 1", "witch 2 watches watch 2"],
        correctAnswer: "witch 1 watches watch 2"
    },
    {
        id: 5,
        question: "The road to hell is paved with _____",
        options: ["bad dreams", "good memories", "red carpets", "good intentions"],
        correctAnswer: "good intentions"
    },
    {
        id: 6,
        question: "how long is long-island?",
        options: ["3 meters", "4 meters", "5 meters", "6 meters"],
        correctAnswer: "4 meters"
    }
]