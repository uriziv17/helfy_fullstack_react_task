import "./stylesheets/App.css";
import PagesRouter from "./PagesRouter";

function App() {
	return <PagesRouter />;
}

export default App;
